#include <iostream.h>

using namespace std;

int main()
{
    if (false or true) {
        cout << "Hello World!";
    }
    return 0;
}

