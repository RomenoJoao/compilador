#include <iostream.h>

using namespace std;

int main()
{
    if (true and true) {
        cout << "Hello World!";
    }
    return 0;
}

