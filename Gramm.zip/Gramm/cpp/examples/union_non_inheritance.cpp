union A
{
};
union B : A
{
};