int main(){
    std::string a = R"(123)\")";

    std::string b = R"(123))))))))))))";
}