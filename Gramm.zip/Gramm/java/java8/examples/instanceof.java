//Instanceof
class InstanceOf{
    public static void main(String[] args){
        if(args instanceof String[]){

        }
        if(args instanceof a.String[]){

        }
    }
}