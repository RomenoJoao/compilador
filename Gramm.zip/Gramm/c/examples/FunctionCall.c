int f(int arg1, char arg2)
{
	a1(arg1);
	a2(arg1, arg2);
	a3();
}