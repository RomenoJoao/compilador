
/* Hello World program */

main()
{
    printf("Hello World");

}

