int i = 0b0011;
int j = 0B1010;
